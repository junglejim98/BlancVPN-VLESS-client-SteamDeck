#!/usr/bin/env bash

set -euo pipefail

REQUIRED_PACKAGES=(
  at-spi2-core
  go
  nodejs
  npm
  dbus
  docker
  base-devel
  brotli
  bzip2
  cairo
  expat
  fontconfig
  fribidi
  freetype2
  gcc
  gdk-pixbuf2
  glib2
  glibc
  graphite
  harfbuzz
  libcloudproviders
  libepoxy
  linux-api-headers
  libjpeg-turbo
  libffi
  libdatrie
  libglvnd
  libnghttp2
  libpng
  libpsl
  libsysprof-capture
  libthai
  libtiff
  libxau
  libxcomposite
  libxcursor
  libxdamage
  libxdmcp
  libxft
  libxfixes
  libxi
  libxinerama
  libxkbcommon
  mesa
  make
  libx11
  libxext
  libxrandr
  libxrender
  libxtst
  libxcb
  gtk3
  webkit2gtk
  webkit2gtk-4.1
  libsoup3
  pango
  pcre2
  pixman
  pkgconf
  shared-mime-info
  sqlite
  systemd-libs
  util-linux
  util-linux-libs
  wayland
  wget
  xorgproto
  xz
  unzip
  curl
  rsync
  zlib
  zstd
)

run_with_privileges() {
  if [[ "$(id -u)" -eq 0 ]]; then
    "$@"
    return
  fi

  if sudo -n true 2>/dev/null; then
    sudo "$@"
    return
  fi

  if [[ -t 0 && -t 1 ]]; then
    sudo "$@"
    return
  fi

  echo "Administrative privileges are required to repair SteamOS build dependencies."
  echo "Run this script from an interactive terminal so sudo can prompt for the deck password:"
  echo "  bash ./install-toolchain-steamdeck.sh"
  exit 1
}

if ! command -v pacman >/dev/null 2>&1; then
  echo "Unsupported system: pacman is required to install Go and npm automatically."
  exit 1
fi

if command -v steamos-readonly >/dev/null 2>&1; then
  echo "Disabling SteamOS readonly mode..."
  run_with_privileges steamos-readonly disable
fi

echo "Initializing pacman keys..."
run_with_privileges pacman-key --init
run_with_privileges pacman-key --populate archlinux holo

echo "Installing build toolchain packages..."
run_with_privileges pacman -Sy --needed --noconfirm "${REQUIRED_PACKAGES[@]}"

echo "Refreshing core GUI dependencies required by Wails..."
run_with_privileges pacman -S --noconfirm \
  at-spi2-core \
  dbus \
  brotli \
  bzip2 \
  cairo \
  expat \
  fontconfig \
  fribidi \
  freetype2 \
  gdk-pixbuf2 \
  glib2 \
  gtk3 \
  graphite \
  harfbuzz \
  libcloudproviders \
  libepoxy \
  libjpeg-turbo \
  libffi \
  libdatrie \
  libglvnd \
  libnghttp2 \
  libpng \
  libpsl \
  libsysprof-capture \
  libthai \
  libtiff \
  libx11 \
  libxau \
  libxcomposite \
  libxcursor \
  libxdamage \
  libxdmcp \
  libxext \
  libxft \
  libxfixes \
  libxi \
  libxinerama \
  libxkbcommon \
  mesa \
  libxrandr \
  libxrender \
  libxtst \
  libxcb \
  libsoup3 \
  pango \
  pcre2 \
  pixman \
  shared-mime-info \
  sqlite \
  systemd-libs \
  util-linux \
  util-linux-libs \
  wayland \
  webkit2gtk \
  webkit2gtk-4.1 \
  xorgproto \
  xz \
  zlib \
  zstd

echo "Toolchain installation completed."
